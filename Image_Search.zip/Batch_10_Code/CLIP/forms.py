from django import forms
from .models import ImageCaption

# class Choose(forms.Form):
#     image_name = forms.ImageField(widget=forms.FileInput(attrs={'class': 'form-control'}))

class Choose(forms.ModelForm):
    class Meta:
        model = ImageCaption
        fields = ['image']