from django.db import models
import os
import collections
import json
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import tensorflow_hub as hub
import tensorflow_text as text
import tensorflow_addons as tfa
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from tqdm import tqdm

# Create your models here.
def load():
    print("Loading utility arrays, query embeddings and image embeddings...")
    image_paths = np.load("image_paths.npy")
    queries = np.load("queries.npy")
    image_embeddings = np.load("image_embeddings.npy")
    query_embeddings = np.load("query_embeddings.npy")
    image_captions = np.load("image_captions.npy")
    print("Embeddings are loaded.")

    print("Loading vision and text encoders...")
    vision_encoder = keras.models.load_model("vision_encoder")
    text_encoder = keras.models.load_model("text_encoder")
    print("Models are loaded.")
    return image_paths, image_captions, queries, image_embeddings, query_embeddings, vision_encoder, text_encoder

class ImageCaption(models.Model):
    image = models.ImageField(name='image', upload_to='CLIP/images')
    caption1 = models.TextField(max_length=100, name='caption1', blank=True, null=True)
    caption2 = models.TextField(max_length=100, name='caption2', blank=True, null=True)
    caption3 = models.TextField(max_length=100, name='caption3', blank=True, null=True)