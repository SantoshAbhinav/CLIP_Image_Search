from django.shortcuts import render
from .models import load
from .forms import Choose
import tensorflow as tf
import os
import PIL
image_paths, image_captions, queries, image_embeddings, query_embeddings, vision_encoder, text_encoder = load()
from .forms import Choose

def read_image(image_path):
    image_array = tf.image.decode_jpeg(tf.io.read_file(image_path), channels=3)
    return tf.image.resize(image_array, (299, 299))


def find_queries(image_embedding, query_embeddings, k=3, normalize=True):
    if normalize:
        image_embedding = tf.math.l2_normalize(image_embedding, axis=1)
        query_embeddings = tf.math.l2_normalize(query_embeddings, axis=1)
    dot_similarity = tf.matmul(image_embedding, query_embeddings, transpose_b=True)
    results = tf.math.top_k(dot_similarity, k).indices.numpy()
    return [[queries[idx] for idx in indices] for indices in results]


def find_matches(image_embeddings, queries, k=9, normalize=True):
    query_embedding = text_encoder(tf.convert_to_tensor(queries))
    if normalize:
        image_embeddings = tf.math.l2_normalize(image_embeddings, axis=1)
        query_embedding = tf.math.l2_normalize(query_embedding, axis=1)
    dot_similarity = tf.matmul(query_embedding, image_embeddings, transpose_b=True)
    results = tf.math.top_k(dot_similarity, k).indices.numpy()
    return [[image_paths[idx] for idx in indices] for indices in results], [[image_captions[idx] for idx in indices] for indices in results]

# Create your views here.

def select(request):
    return render(request, 'CLIP/select.html')

def home(request):
    return render(request, 'CLIP/home.html')

def upload(request):
    form = Choose()
    return render(request, 'CLIP/upload.html', {'form' : form})

# def caption(request):
#     if request.method == 'POST':
#         image_name = request.POST.get('image_name')
#         image_path = os.path.join('CLIP/static/images/train2014/', image_name)
#         print("Generating embeddings for given image...")
#         image_embedding = vision_encoder.predict(
#             tf.data.Dataset.from_tensor_slices([image_path]).map(read_image).batch(1),
#             verbose=1
#             )
#         matches = find_queries(image_embedding, query_embeddings, normalize=True)[0]
#         print("Top 3 Image captions for the given image")
#         caption1 = matches[0]
#         caption2 = matches[1]
#         caption3 = matches[2]
#         object = ImageCaption(image=image_path, caption1 = caption1, caption2 = caption2, caption3 = caption3)
#         object.save()
#         source = os.path.join('images/train2014', image_name)
#         return render(request, 'CLIP/caption.html', {'image_path' : source, 'caption1' : caption1})

def caption(request):
    if request.method == 'POST':
        object = Choose(request.POST, request.FILES)
        print(object.errors)
        if object.is_valid():
            new_obj = object.save()
            image_path = new_obj.image.url
            print(image_path)
            print("Generating embeddings for given image...")
            image_embedding = vision_encoder.predict(
                tf.data.Dataset.from_tensor_slices([image_path[1:]]).map(read_image).batch(1),
                verbose=1
                )
            matches = find_queries(image_embedding, query_embeddings, normalize=True)[0]
            print("Top 3 Image captions for the given image")
            caption1 = matches[0]
            caption2 = matches[1]
            caption3 = matches[2]
            new_obj.caption1 = caption1
            new_obj.caption2 = caption2
            new_obj.caption3 = caption3
            new_obj.save()
            return render(request, 'CLIP/caption.html', {'image_path' : image_path, 'caption1' : caption1, 'caption2' : caption2, 'caption3' : caption3})

def images(request):
    if request.method == 'GET':
        return render(request, 'CLIP/home.html')
    elif request.method == 'POST':
        text = request.POST.get('search')
        image_paths_, image_captions_ = find_matches(image_embeddings, [text], normalize=True)
        paths = []
        image_caption_pairs = {}
        for i in image_paths_[0]:
            paths.append(os.path.join('images/', i[9:]))
        for i in range(9):
            image_caption_pairs[paths[i]] = image_captions_[0][i]
        return render(request, 'CLIP/images.html', {'text' : text, 'image_caption_pairs' : image_caption_pairs})